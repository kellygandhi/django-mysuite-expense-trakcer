// Smooth theme toggle
const toggle = document.getElementById("themeToggle");
const html = document.documentElement;

if (localStorage.getItem("theme")) {
  html.setAttribute("data-theme", localStorage.getItem("theme"));
  toggle.textContent = localStorage.getItem("theme") === "dark" ? "🌙" : "☀️";
}

toggle.addEventListener("click", () => {
  const theme = html.getAttribute("data-theme") === "light" ? "dark" : "light";
  html.setAttribute("data-theme", theme);
  localStorage.setItem("theme", theme);
  toggle.textContent = theme === "dark" ? "🌙" : "☀️";
});

// Reveal on scroll
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add("fade-in");
  });
}, { threshold: 0.1 });

document.querySelectorAll(".card").forEach(el => observer.observe(el));
// Animate group cards in sequence
document.querySelectorAll('.group-card').forEach((card, i) => {
  card.style.setProperty('--i', i);
});

// Smooth scroll reveal on page load
window.addEventListener('load', () => {
  document.querySelectorAll('.fade-in').forEach((el, i) => {
    el.style.animationDelay = `${i * 0.1}s`;
  });
});
