from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Sum
from .models import Group, Member, Expense, Task

# ----------------------------
# 🏠 DASHBOARD
# ----------------------------
def home(request):
    total_groups = Group.objects.count()
    total_expenses = Expense.objects.aggregate(Sum('amount'))['amount__sum'] or 0
    total_tasks = Task.objects.count()

    context = {
        'total_groups': total_groups,
        'total_expenses': round(total_expenses, 2),
        'total_tasks': total_tasks,
    }
    return render(request, 'dashboard.html', context)


# ----------------------------
# 💰 EXPENSES (Groups)
# ----------------------------
def expenses(request):
    """Main Expense page showing all groups."""
    groups = Group.objects.all().order_by('-id')
    return render(request, 'expenses.html', {'groups': groups})


def add_group(request):
    """Handles creation of a new group."""
    if request.method == "POST":
        name = request.POST.get("name")
        if name:
            Group.objects.create(name=name)
        return redirect("expenses")
    return redirect("expenses")


def group_detail(request, group_id):
    """Show and add expenses for a specific group."""
    group = get_object_or_404(Group, id=group_id)
    expenses = group.expenses.all().order_by('-id')
    total = expenses.aggregate(Sum('amount'))['amount__sum'] or 0
    members = group.members.all()

    # Add expense logic
    if request.method == "POST":
        description = request.POST.get("description")
        amount = request.POST.get("amount")
        if description and amount:
            member, _ = Member.objects.get_or_create(name="You", group=group)
            Expense.objects.create(
                group=group,
                description=description,
                amount=float(amount),
                paid_by=member
            )
            return redirect("group_detail", group_id=group.id)

    context = {
        "group": group,
        "expenses": expenses,
        "total": total,
        "members": members
    }
    return render(request, "group_detail.html", context)


# ----------------------------
# ✅ TASKS
# ----------------------------
def tasks(request):
    """Display and add personal tasks."""
    if request.method == "POST":
        title = request.POST.get("title")
        deadline = request.POST.get("deadline")
        if title:
            Task.objects.create(title=title, deadline=deadline)
        return redirect("tasks")

    all_tasks = Task.objects.all().order_by('deadline')

    # Automatically set urgency levels
    for task in all_tasks:
        if not task.deadline:
            task.urgency = "Low"
        else:
            from datetime import date
            days_left = (task.deadline - date.today()).days
            if days_left < 0:
                task.urgency = "Overdue"
            elif days_left <= 2:
                task.urgency = "High"
            elif days_left <= 5:
                task.urgency = "Medium"
            else:
                task.urgency = "Low"

    return render(request, "tasks.html", {"tasks": all_tasks})
