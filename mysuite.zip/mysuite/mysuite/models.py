from django.db import models

class Group(models.Model):
    name = models.CharField(max_length=100)
    def __str__(self):
        return self.name

class Member(models.Model):
    name = models.CharField(max_length=100)
    group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name="members")
    def __str__(self):
        return self.name

class Expense(models.Model):
    group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name="expenses")
    description = models.CharField(max_length=255)
    amount = models.FloatField()
    paid_by = models.ForeignKey(Member, on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"{self.description} ({self.amount})"

class Task(models.Model):
    title = models.CharField(max_length=255)
    deadline = models.DateField(null=True, blank=True)
    urgency = models.CharField(max_length=20, default="Low")
    def __str__(self):
        return self.title
