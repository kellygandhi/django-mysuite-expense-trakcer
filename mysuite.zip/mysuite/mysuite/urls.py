from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('expenses/', views.expenses, name='expenses'),
    path('tasks/', views.tasks, name='tasks'),
    path('add-group/', views.add_group, name='add_group'),  # ✅ new
    path('group/<int:group_id>/', views.group_detail, name='group_detail'),  # ✅ new
]
